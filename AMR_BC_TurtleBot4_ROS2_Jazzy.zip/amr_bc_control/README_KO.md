# TurtleBot4 AMR: B/C 구역 자율주행 + 차량 접근 (ROS 2 Jazzy)

업로드한 `minimap.yaml` + `minimap.pgm`에 맞춘 교육/시험용 ROS 2 코드입니다.

**이 패키지의 실제 로봇 실행은 검증되지 않았습니다.** 기본 실행은 프리뷰/수동 START 방식이며, **--execute 없이 로봇이 움직이지 않습니다.**

## 구성

- `bc_nav_only.py` : B -> C Nav2 경유지 이동. 기본은 **오프라인 맵 검증/프리뷰**. `--execute` 지정 시 Nav2 액션 호출.
- `amr_bc_controller.py` : `START` 이벤트 -> DockStatus 확인 -> Undock -> /initialpose 발행 -> AMCL/TF 확인 -> B -> C -> 탐색/차량 접근 시도. 기본은 dry-run, `--execute` 필요.
- `approach_core.py` : ROS 비의존 2D 맵/Depth/접근 목표 계산. `car`만 유효 대상으로 허용하고 `dummy` 제외.
- `tests/test_approach_core.py` : 11개 오프라인 유닛 테스트.
- `minimap.yaml`, `minimap.pgm` : 원본 맵.
- `bc_preview.png` : B/C 경유지와 연결 경로의 **2D 맵 프리뷰** (Nav2 실제 계획 경로 아님).
- `SYSTEM_REQUIREMENTS.md` : 요구사항 및 테스트 단계.

## 사용 좌표 (`map` frame)

- B = (-2.15, 1.40)
- C = (-1.00, -0.50)

위 좌표는 **시험용**이며, 로봇 크기/실제 장애물/AMCL 오차까지 검증된 목적지는 아닙니다. 현재 맵은 `0.05 m/pixel`, origin `(-5.558, -10.041, 0)`입니다.

## 0. 환경 준비

기존 ROS 2 Jazzy + `rokey_venv` + `~/rokey_ws` 구성 예시입니다. PC에서 Nav2/AMCL이 **별도 터미널/런치에서 이미 실행 중**이어야 합니다. 이 코드는 Nav2 서버나 map_server를 시작하지 않습니다.

```bash
source /opt/ros/jazzy/setup.bash
source ~/venvs/rokey_venv/bin/activate
source ~/rokey_ws/install/setup.bash
cd ~/rokey_ws/amr_bc_control
```

필요 Python 모듈: `numpy`, `opencv-python` (또는 `opencv-python-headless`), `PyYAML`. 통합 제어에는 `ultralytics`, `cv_bridge`, `rclpy`, `tf2_ros`, `tf2_geometry_msgs`, `message_filters`, `irobot_create_msgs`, `nav2_msgs`, `action_msgs`도 필요합니다. ROS 관련 모듈은 ROS 2 환경의 apt 패키지 구성을 우선 사용하세요.

## 1. PC에서 코드를 먼저 검사 (로봇 미이동)

```bash
python3 -m unittest discover -s tests -v
python3 bc_nav_only.py --preview bc_preview.png
```

## 2. Nav2 준비 확인 (로봇 미이동)

실제로 실행 중인 액션 이름은 장비 환경에 따라 다르므로 아래로 확인하세요.

```bash
ros2 action list | grep -E 'undock|navigate_to_pose'
ros2 topic list | grep -E 'dock_status|amcl_pose|oakd|initialpose'
ros2 topic echo --once /robot3/dock_status
```

Nav2가 이번 SLAM 맵을 읽고 있어야 하고, RViz에서 로봇 위치와 local/global costmap, map -> base_link TF를 확인해야 합니다.

## 3. B -> C 자율주행만 테스트

- 로봇을 언도킹한 상태에서 주변을 비우고, **RViz의 2D Pose Estimate로 실제 초기 위치를 정확히 입력**하세요.
- RViz에서 Nav2 경로가 정상인지 확인한 후, 아래의 액션 이름을 확인된 값으로 바꿔 사용합니다.

```bash
python3 bc_nav_only.py --execute --nav-action /robot3/navigate_to_pose
```

네임스페이스 없는 Nav2인 경우 `--nav-action /navigate_to_pose`로 변경하세요. 역방향은 `--reverse`를 추가합니다.

## 4. AMR 통합 제어 (실기 전 사전 확인 필수)

`amr_bc_controller.py`의 기본 모드는 **dry-run**으로, 실제 undock/nav 명령을 보내지 않습니다. 다만 프로그램이 시작할 때 YOLO 가중치를 로드하므로 `model_path`는 실제 존재하는 `.pt` 경로여야 합니다.

먼저 시작 전 아래 항목을 확인하세요:

1. 실제 로봇이 언도킹 이후 도달할 위치/방향을 `map` 좌표로 측정합니다. 이 값은 B/C 좌표로 대신하면 안 됩니다.
2. `ros2 action list`, `ros2 topic list`에서 실제 네임스페이스와 토픽을 확인합니다.
3. Nav2/AMCL과 지정된 맵이 정상 작동하는지 확인합니다.
4. **RGB와 Depth의 픽셀 정렬을 실제로 검증하기 전에는** 접근 기능을 활성화하지 않습니다. 기본 `confirm_aligned_depth=false`입니다.
5. `.pt` 모델의 클래스 이름이 `car`와 `dummy`인지 확인합니다.

실제값을 환경변수에 입력한 뒤 실행하세요 (실제 측정값을 넣어야 합니다):

```bash
# 반드시 실제 언도킹 이후 map상의 pose 수치를 입력
# export INIT_X=... ; export INIT_Y=... ; export INIT_YAW_DEG=...
# export MODEL_PT=/실제/경로/best.pt

python3 amr_bc_controller.py --execute --ros-args \
  -r __ns:=/robot3 \
  -p model_path:="$MODEL_PT" \
  -p initial_x:="$INIT_X" \
  -p initial_y:="$INIT_Y" \
  -p initial_yaw_deg:="$INIT_YAW_DEG" \
  -p confirm_aligned_depth:=false
```

별도 터미널에서 START 이벤트를 보냅니다:

```bash
ros2 topic pub --once /robot3/amr/event std_msgs/msg/String "{data: START}"
```

정지는:

```bash
ros2 topic pub --once /robot3/amr/event std_msgs/msg/String "{data: STOP}"
```

**STOP은 작업 취소 요청이지 비상정지(E-stop)가 아닙니다.** 실제 위험 상황에는 장비의 정식 비상정지 수단을 사용하세요.

상태와 목표 정보:

```bash
ros2 topic echo /robot3/amr/status
ros2 topic echo /robot3/amr/target_info
```

`amr_bc_controller.py`는 `--execute`가 있어도 `confirm_aligned_depth=false`인 경우 자동 차량 접근을 수행하지 않습니다. 차량 접근을 시험하려면 검증된 RGB-aligned depth 토픽을 사용하도록 `depth_topic`을 지정하고, RGB/Depth 픽셀 정렬 + CameraInfo + TF를 점검한 뒤에만 `confirm_aligned_depth:=true`로 변경하세요.

## 한계 / 주의사항

- **현재 안전 구역 검사는 접근 목표점의 맵 자유 공간 및 B-C 주변 통로 여부만 검사**합니다. Nav2가 계산한 실제 경로 또는 차체가 B·C 이외 영역에 진입하지 않음을 보장하지 않습니다. 엄격한 구역 제한은 Nav2 Keepout Filter + 실제 footprint/costmap 검증이 필요합니다.
- 실제 로봇의 초기 위치, 도크 위치는 사용자에게서 제공되지 않았으므로 자동 추정하지 않습니다. 초기 위치를 잘못 설정하면 위험합니다.
- RGB와 Depth의 해상도가 같아도 공간 정렬은 보장되지 않습니다. 시간 동기화만으로 충분하지 않습니다.
- YOLO 대상 추적 ID와 거리가 변동될 수 있으며, 실제 차량 접근시 장애물 인지, 속도 제한, 오탐 방지가 추가로 검증되어야 합니다.
- 이 코드는 실제 TurtleBot4에서 주행/언도킹 성공 여부를 측정한 결과가 아닙니다. 유닛 테스트는 수학/데이터/오프라인 맵 검증에만 해당합니다.
