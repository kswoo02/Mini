#!/usr/bin/env python3
"""Event-driven TurtleBot4 /robot3 controller: undock, localize, B-C, car approach.

Requires ROS 2 Jazzy, irobot_create_msgs, nav2_msgs, tf2_geometry_msgs,
message_filters, cv_bridge, ultralytics, PyYAML, NumPy, OpenCV.

SAFE DEFAULT: --execute must be specified. Further, no START mission begins
without user-provided initial pose. Target navigation is DISABLED unless
confirm_aligned_depth:=true is set after physical RGB/Depth alignment checks.
"""
import argparse
import json
import math
from pathlib import Path
import time

import cv2
import numpy as np
from ultralytics import YOLO

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.duration import Duration
from rclpy.qos import qos_profile_sensor_data, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from action_msgs.msg import GoalStatus
from cv_bridge import CvBridge
from geometry_msgs.msg import PointStamped, PoseStamped, PoseWithCovarianceStamped
from irobot_create_msgs.msg import DockStatus
from irobot_create_msgs.action import Undock
from nav2_msgs.action import NavigateToPose
from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import String
from message_filters import Subscriber, ApproximateTimeSynchronizer
from tf2_ros import Buffer, TransformListener, TransformException
from tf2_geometry_msgs import do_transform_point

from approach_core import B, C, MapGuard, find_approach_goal, eligible_target_class, robust_depth_m


class AMRController(Node):
    def __init__(self, execute=False):
        super().__init__('amr_bc_controller')
        self.execute = execute
        here = Path(__file__).resolve().parent
        def param(name, value):
            self.declare_parameter(name, value)
            return self.get_parameter(name).value

        self.model_path = str(param('model_path', str(here / 'best.pt')))
        self.map_yaml = str(param('map_yaml', str(here / 'minimap.yaml')))
        self.init_x = float(param('initial_x', float('nan')))
        self.init_y = float(param('initial_y', float('nan')))
        self.init_yaw_deg = float(param('initial_yaw_deg', float('nan')))
        self.depth_confirmed = bool(param('confirm_aligned_depth', False))
        self.rgb_topic = str(param('rgb_topic', 'oakd/rgb/image_raw'))
        self.depth_topic = str(param('depth_topic', 'oakd/stereo/image_raw'))
        self.info_topic = str(param('camera_info_topic', 'oakd/rgb/camera_info'))
        self.map_frame = str(param('map_frame', 'map'))
        self.base_frame = str(param('base_frame', 'base_link'))
        self.standoff_m = float(param('standoff_m', 0.80))
        self.min_conf = float(param('min_confidence', 0.65))
        self.target_timeout_s = float(param('target_timeout_s', 1.5))
        self.replan_distance_m = float(param('replan_distance_m', 0.45))
        self.guard = MapGuard(self.map_yaml)
        self.bridge = CvBridge()
        self.model = YOLO(self.model_path)

        self.state = 'IDLE'
        self.docked = None
        self.camera_info = None
        self.initialized_at = None
        self.last_pose_pub = 0.0
        self.last_amcl_time = 0.0
        self.last_amcl_xy = None
        self.undock_deadline = 0.0
        self.localize_deadline = 0.0
        self.mission_started = False
        self.last_frame_processed = 0.0
        self.candidate_id = None
        self.candidate_count = 0
        self.target = None
        self.locked_target_id = None
        self.nav_handle = None
        self.undock_handle = None
        self.undock_pending = False
        self.nav_goal_pending = False
        self.nav_seq = 0
        self.nav_goal_xy = None
        self.nav_sent_time = 0.0
        self.cancel_pending = None
        self.next_patrol = 'B'
        self.search_dwell_until = 0.0
        self.last_status = None

        self.undock_client = ActionClient(self, Undock, 'undock')
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.initial_pub = self.create_publisher(PoseWithCovarianceStamped, 'initialpose', 10)
        self.target_pub = self.create_publisher(String, 'amr/target_info', 10)
        self.status_pub = self.create_publisher(String, 'amr/status', 10)
        self.create_subscription(String, 'amr/event', self.on_event, 10)
        self.create_subscription(DockStatus, 'dock_status', self.on_dock, qos_profile_sensor_data)
        self.create_subscription(PoseWithCovarianceStamped, 'amcl_pose', self.on_amcl, 10)
        self.create_subscription(CameraInfo, self.info_topic, self.on_camera_info, qos_profile_sensor_data)
        self.tf_buffer = Buffer(cache_time=Duration(seconds=10))
        self.tf_listener = TransformListener(self.tf_buffer, self)
        # Both channels must be synchronized; pixel alignment must ALSO be validated.
        self.rgb_sub = Subscriber(self, Image, self.rgb_topic, qos_profile=qos_profile_sensor_data)
        self.depth_sub = Subscriber(self, Image, self.depth_topic, qos_profile=qos_profile_sensor_data)
        self.sync = ApproximateTimeSynchronizer(
            [self.rgb_sub, self.depth_sub], queue_size=12, slop=0.12)
        self.sync.registerCallback(self.on_rgb_depth)
        self.timer = self.create_timer(0.2, self.tick)
        self.get_logger().info(
            'B-C controller ready. Mode=%s. START event required. '
            'Depth alignment confirmed=%s' % ('EXECUTE' if execute else 'DRY-RUN', self.depth_confirmed))
        if not self.depth_confirmed:
            self.get_logger().warn('Approach disabled: confirm RGB-registered depth before enabling.')
        if not self.execute:
            self.get_logger().warn('DRY-RUN: no Undock or NavigateToPose actions will be sent.')

    def status(self, message=''):
        data = {'state': self.state, 'message': message, 'time': time.time()}
        self.status_pub.publish(String(data=json.dumps(data, ensure_ascii=False)))
        if message:
            self.get_logger().info(f'[{self.state}] {message}')

    def fault(self, reason):
        self.state = 'FAULT'
        self.mission_started = False
        self.status(reason)
        if self.undock_handle is not None:
            self.undock_handle.cancel_goal_async()
        self._cancel_nav(None)

    def on_dock(self, msg):
        self.docked = bool(msg.is_docked)

    def on_amcl(self, msg):
        if msg.header.frame_id and msg.header.frame_id != self.map_frame:
            return
        self.last_amcl_time = time.monotonic()
        self.last_amcl_xy = (float(msg.pose.pose.position.x), float(msg.pose.pose.position.y))

    def on_camera_info(self, msg):
        if msg.k[0] > 0 and msg.k[4] > 0:
            self.camera_info = msg

    def on_event(self, msg):
        event = msg.data.strip().upper()
        if event == 'START':
            if self.state not in ('IDLE', 'HOLD'):
                self.status(f'Ignored START while state={self.state}')
                return
            if self.state == 'HOLD':
                self.locked_target_id = None
                self.target = None
                self.candidate_count = 0
                self.state = 'SEARCH'
                self.search_dwell_until = time.monotonic() + 2
                self.status('Resume search after approach')
                return
            if self.undock_pending:
                self.status('Undock action still pending; do not restart')
                return
            if not self.execute:
                self.status('DRY-RUN START: would undock, publish initial pose, navigate B->C and approach car')
                return
            if not all(math.isfinite(v) for v in (self.init_x, self.init_y, self.init_yaw_deg)):
                self.fault('Set initial_x/y/yaw_deg from REAL post-undock pose before START')
                return
            if not self.guard.cell((self.init_x, self.init_y)):
                self.fault('Initial pose outside supplied SLAM map')
                return
            self.target = None
            self.candidate_id = None
            self.candidate_count = 0
            self.locked_target_id = None
            self.mission_started = True
            self.state = 'WAIT_DOCK_STATUS'
            self.undock_deadline = time.monotonic() + 15
            self.status('Event accepted; checking dock status')
            self._start_if_status_available()
        elif event == 'STOP':
            self.state = 'STOPPED'
            if self.undock_handle is not None:
                self.undock_handle.cancel_goal_async()
            self.target = None
            self.mission_started = False
            self.status('STOP: cancelling motion; no auto-dock')
            self._cancel_nav('IDLE')
            if self.nav_handle is None and not self.nav_goal_pending and not self.undock_pending:
                self.state = 'IDLE'
        elif event == 'RESET' and self.state in ('FAULT', 'STOPPED'):
            self.state = 'IDLE'
            self.status('Fault reset; verify hazards before START')

    def _start_if_status_available(self):
        if self.state != 'WAIT_DOCK_STATUS' or self.docked is None:
            return
        if self.docked:
            if not self.undock_client.server_is_ready():
                if not self.undock_client.wait_for_server(timeout_sec=0.0):
                    self.fault('Undock action server missing (check namespace)')
                    return
            self.state = 'UNDOCKING'
            self.undock_pending = True
            self.undock_deadline = time.monotonic() + 65
            self.status('Undock action sent')
            fut = self.undock_client.send_goal_async(Undock.Goal())
            fut.add_done_callback(self._undock_goal_response)
        else:
            self.status('Robot already undocked, skipping Undock action')
            self._initialize_pose()

    def _undock_goal_response(self, future):
        try:
            gh = future.result()
            if not gh or not gh.accepted:
                self.undock_pending = False
                if self.state == 'UNDOCKING':
                    self.fault('Undock action was rejected')
                elif self.state == 'STOPPED':
                    self.state = 'IDLE'
                return
            self.undock_handle = gh
            gh.get_result_async().add_done_callback(self._undock_result)
            if self.state != 'UNDOCKING':
                gh.cancel_goal_async()  # STOP/FAULT arrived before action accepted
        except Exception as e:
            self.undock_pending = False
            if self.state == 'UNDOCKING':
                self.fault(f'Undock action error: {e}')

    def _undock_result(self, future):
        self.undock_handle = None
        self.undock_pending = False
        if self.state == 'STOPPED':
            self.state = 'IDLE'
            self.status('Undock cancel/completion reported; verify dock status')
            return
        if self.state != 'UNDOCKING':
            return
        try:
            result = future.result()
            if result.status != GoalStatus.STATUS_SUCCEEDED:
                self.fault(f'Undock failed, action status={result.status}')
                return
            self._initialize_pose()
        except Exception as e:
            self.fault(f'Undock result error: {e}')

    def _initialize_pose(self):
        self.state = 'LOCALIZING'
        self.localize_deadline = time.monotonic() + 25
        self.initialized_at = time.monotonic()
        self.last_amcl_time = 0.0
        self.status('Publishing post-undock initial pose; waiting for fresh AMCL estimate')
        self._publish_initial_pose()

    def _publish_initial_pose(self):
        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = self.map_frame
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.pose.position.x, msg.pose.pose.position.y = self.init_x, self.init_y
        yaw = math.radians(self.init_yaw_deg)
        msg.pose.pose.orientation.z = math.sin(yaw/2)
        msg.pose.pose.orientation.w = math.cos(yaw/2)
        msg.pose.covariance[0] = 0.10
        msg.pose.covariance[7] = 0.10
        msg.pose.covariance[35] = 0.12
        self.initial_pub.publish(msg)
        self.last_pose_pub = time.monotonic()

    def _robot_xy(self):
        try:
            tf = self.tf_buffer.lookup_transform(self.map_frame, self.base_frame, Time())
            return float(tf.transform.translation.x), float(tf.transform.translation.y)
        except TransformException:
            return None

    def _goal_pose(self, x, y, yaw):
        msg = PoseStamped()
        msg.header.frame_id = self.map_frame
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.position.x = float(x)
        msg.pose.position.y = float(y)
        msg.pose.orientation.z = math.sin(yaw / 2)
        msg.pose.orientation.w = math.cos(yaw / 2)
        return msg

    def _navigate(self, x, y, yaw, stage):
        if self.state in ('FAULT', 'IDLE', 'STOPPED'):
            return
        if self.nav_goal_pending or self.nav_handle is not None:
            self.status('Navigation busy; refusing overlapping goal')
            return
        if not self.guard.safe_goal((x, y)):
            self.fault(f'Rejected {stage} goal outside clearance-screened B-C corridor: ({x:.2f},{y:.2f})')
            return
        if not self.nav_client.wait_for_server(timeout_sec=0.0):
            self.fault('Nav2 navigate_to_pose action unavailable')
            return
        self.state = stage
        self.nav_goal_xy = (x, y)
        self.nav_sent_time = time.monotonic()
        self.nav_goal_pending = True
        self.nav_seq += 1
        seq = self.nav_seq
        req = NavigateToPose.Goal()
        req.pose = self._goal_pose(x, y, yaw)
        self.status(f'Nav2 goal ({x:.2f}, {y:.2f}), yaw={math.degrees(yaw):.1f} deg')
        f = self.nav_client.send_goal_async(req)
        f.add_done_callback(lambda fut: self._nav_accepted(fut, seq))

    def _nav_accepted(self, future, seq):
        if seq != self.nav_seq:
            return
        self.nav_goal_pending = False
        try:
            gh = future.result()
            if not gh or not gh.accepted:
                self.fault('Nav2 rejected goal')
                return
            self.nav_handle = gh
            gh.get_result_async().add_done_callback(lambda fut: self._nav_result(fut, seq))
            if self.cancel_pending is not None:
                gh.cancel_goal_async()
        except Exception as e:
            self.fault(f'Nav2 goal exception: {e}')

    def _nav_result(self, future, seq):
        if seq != self.nav_seq:
            return
        self.nav_handle = None
        self.nav_goal_pending = False
        try:
            status = future.result().status
        except Exception as e:
            self.fault(f'Nav2 result exception: {e}')
            return
        if self.state in ('FAULT', 'STOPPED') and self.cancel_pending != 'IDLE':
            self.cancel_pending = None
            return
        if self.cancel_pending is not None:
            after = self.cancel_pending
            self.cancel_pending = None
            if after == 'IDLE':
                self.state = 'IDLE'
                self.status('Navigation stopped')
            elif after == 'APPROACH':
                self._start_approach()
            elif after == 'SEARCH':
                self.state = 'SEARCH'
                self.search_dwell_until = time.monotonic() + 2
                self.status('Target lost/moved: reacquiring')
            return
        if self.state in ('FAULT', 'STOPPED', 'IDLE'):
            return
        if status != GoalStatus.STATUS_SUCCEEDED:
            self.fault(f'Nav2 failed/canceled unexpectedly (status={status})')
            return
        if self.state == 'NAV_B':
            if not self.mission_started:
                return
            self._navigate(C[0], C[1], -1.0, 'NAV_C')
        elif self.state == 'NAV_C':
            self.state = 'SEARCH'
            self.next_patrol = 'B'
            self.search_dwell_until = time.monotonic() + 2.0
            self.status('Arrived C; searching for valid car target')
        elif self.state == 'APPROACH':
            self.state = 'HOLD'
            self.status('Approach goal reached; waiting for START or STOP')

    def _cancel_nav(self, after):
        if after is not None:
            self.cancel_pending = after
        if self.nav_handle is not None:
            self.nav_handle.cancel_goal_async()
        elif self.nav_goal_pending:
            # Once the goal is accepted, the result handler will cancel it.
            pass
        elif self.cancel_pending is not None:
            task = self.cancel_pending
            self.cancel_pending = None
            if task == 'IDLE':
                self.state = 'IDLE'
            elif task == 'APPROACH':
                self._start_approach()
            elif task == 'SEARCH':
                self.state = 'SEARCH'
                self.search_dwell_until = time.monotonic() + 2

    def _start_approach(self):
        if self.state in ('FAULT', 'STOPPED', 'IDLE'):
            return
        if not self.depth_confirmed:
            self.state = 'SEARCH'
            self.status('Approach blocked: RGB-registered depth not confirmed')
            return
        if self.target is None or time.monotonic()-self.target['seen'] > self.target_timeout_s:
            self.state = 'SEARCH'
            self.search_dwell_until = time.monotonic() + 1.0
            self.status('Target is stale, returning to search')
            return
        robot = self._robot_xy()
        if robot is None:
            self.fault('Cannot transform base_link to map before approach')
            return
        try:
            goal = find_approach_goal(robot, (self.target['x'], self.target['y']),
                                      self.guard, self.standoff_m)
        except ValueError as e:
            self.state = 'SEARCH'
            self.search_dwell_until = time.monotonic() + 1
            self.status(f'Unsafe target approach rejected: {e}')
            return
        if goal is None:
            self.state = 'HOLD'
            self.status('Already within standoff range; no movement')
            return
        self.locked_target_id = self.target['track_id']
        self._navigate(*goal, stage='APPROACH')

    def on_rgb_depth(self, rgb_msg, depth_msg):
        now = time.monotonic()
        if now-self.last_frame_processed < 0.25:
            return
        self.last_frame_processed = now
        if self.state not in ('NAV_B','NAV_C','SEARCH','APPROACH','HOLD'):
            return
        if not self.depth_confirmed or self.camera_info is None:
            return
        if rgb_msg.header.frame_id == '':
            return
        try:
            rgb = self.bridge.imgmsg_to_cv2(rgb_msg, desired_encoding='bgr8')
            depth = self.bridge.imgmsg_to_cv2(depth_msg, desired_encoding='passthrough')
        except Exception as e:
            self.get_logger().warn(f'Camera decode error: {e}')
            return
        if rgb is None or depth is None or rgb.shape[:2] != depth.shape[:2]:
            # Equal sizes are necessary, NOT sufficient, for alignment.
            return
        info = self.camera_info
        if info.width != rgb.shape[1] or info.height != rgb.shape[0]:
            return
        if depth_msg.encoding not in ('16UC1', '32FC1'):
            return
        try:
            output = self.model.track(rgb, persist=True, conf=self.min_conf,
                                      tracker='bytetrack.yaml', verbose=False)
        except Exception as e:
            self.get_logger().warn(f'YOLO tracking failure: {e}')
            return
        if not output or output[0].boxes is None:
            self.candidate_count = 0
            return
        results = output[0]
        candidates = []
        for box in results.boxes:
            cls = int(box.cls[0])
            name = str(self.model.names[cls]).lower().strip()
            if not eligible_target_class(name):
                continue  # Explicitly exclude dummy and any other class
            if box.id is None:
                continue  # Require stable tracker identity
            ident = int(box.id[0])
            confidence = float(box.conf[0])
            x1, y1, x2, y2 = [int(v) for v in box.xyxy[0].tolist()]
            u, v = (x1+x2)//2, (y1+y2)//2
            z = robust_depth_m(depth, (x1,y1,x2,y2), depth_msg.encoding)
            if z is None:
                continue
            fx, fy, cx, cy = info.k[0], info.k[4], info.k[2], info.k[5]
            if fx <= 0 or fy <= 0:
                continue
            pt = PointStamped()
            pt.header = rgb_msg.header
            pt.point.x, pt.point.y, pt.point.z = (u-cx)*z/fx, (v-cy)*z/fy, z
            try:
                tf = self.tf_buffer.lookup_transform(self.map_frame,
                    rgb_msg.header.frame_id, Time.from_msg(rgb_msg.header.stamp),
                    timeout=Duration(seconds=0.0))
                mapped = do_transform_point(pt, tf)
            except Exception:
                continue
            candidates.append({'class': name, 'track_id': ident, 'confidence': confidence,
                'pixel': [u,v], 'depth_m': round(z,3), 'x': float(mapped.point.x),
                'y': float(mapped.point.y), 'seen': now})
        if not candidates:
            self.candidate_count = 0
            return
        if self.locked_target_id is not None:
            selected = next((c for c in candidates if c['track_id'] == self.locked_target_id), None)
            if selected is None:
                return
        else:
            selected = max(candidates, key=lambda c: c['confidence'])
        ident = selected['track_id']
        if ident == self.candidate_id:
            self.candidate_count += 1
        else:
            self.candidate_id = ident
            self.candidate_count = 1
        if self.candidate_count < 3:
            return
        self.target = selected
        report = {k: v for k,v in selected.items() if k != 'seen'}
        self.target_pub.publish(String(data=json.dumps(report, ensure_ascii=False)))
        if self.state in ('NAV_B', 'NAV_C') and self.cancel_pending is None:
            self.status(f'Confirmed car ID {ident}; canceling patrol for approach')
            self._cancel_nav('APPROACH')
        elif self.state == 'SEARCH':
            self._start_approach()

    def tick(self):
        now = time.monotonic()
        if self.state == 'WAIT_DOCK_STATUS':
            if now > self.undock_deadline:
                self.fault('Dock status timeout')
            else:
                self._start_if_status_available()
        elif self.state == 'UNDOCKING':
            if now > self.undock_deadline:
                self.fault('Undock action timed out; check dock/robot condition')
        elif self.state == 'LOCALIZING':
            if now > self.localize_deadline:
                self.fault('AMCL localization timeout; check init pose, TF and map')
                return
            if now-self.last_pose_pub > 2.0:
                self._publish_initial_pose()
            if self.last_amcl_time > self.initialized_at and self.last_amcl_xy is not None:
                dx = self.last_amcl_xy[0]-self.init_x
                dy = self.last_amcl_xy[1]-self.init_y
                if math.hypot(dx,dy) < 0.9 and self._robot_xy() is not None:
                    self.status('Fresh AMCL estimate + map TF confirmed; navigating to B')
                    self._navigate(B[0], B[1], -0.95, 'NAV_B')
        elif self.state == 'SEARCH':
            if now >= self.search_dwell_until and not self.nav_goal_pending and self.nav_handle is None:
                if self.next_patrol == 'B':
                    self.next_patrol = 'C'
                    self._navigate(B[0], B[1], 0.0, 'NAV_B')
                else:
                    self.next_patrol = 'B'
                    self._navigate(C[0], C[1], -1.0, 'NAV_C')
        elif self.state == 'APPROACH':
            if self.cancel_pending is not None:
                return
            if self.target is None or now-self.target['seen'] > self.target_timeout_s:
                self.status('Lost target during approach; cancelling Nav2 goal')
                self._cancel_nav('SEARCH')
            elif self.nav_goal_xy and now-self.nav_sent_time > 2.5:
                robot = self._robot_xy()
                if robot:
                    try:
                        updated = find_approach_goal(robot, (self.target['x'],self.target['y']),
                                                      self.guard,self.standoff_m)
                        if updated is not None and math.dist(updated[:2], self.nav_goal_xy) > self.replan_distance_m:
                            self.status('Target moved; cancelling to recompute approach goal')
                            self._cancel_nav('APPROACH')
                    except ValueError:
                        self._cancel_nav('SEARCH')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--execute', action='store_true',
                    help='Allow physical undock and Nav2 motion on START event')
    args, ros_args = ap.parse_known_args()
    rclpy.init(args=ros_args)
    node = None
    try:
        node = AMRController(execute=args.execute)
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node._cancel_nav('IDLE')
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
