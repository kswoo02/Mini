# mini_project_rokey > mini_project_rokey
https://universe.roboflow.com/1213-qgwp3/mini_project_rokey

Provided by a Roboflow user
License: CC BY 4.0

